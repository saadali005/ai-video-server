# AI Video Server (Node.js)

## Setup

1. Install dependencies:
   ```bash
   npm install
   ```

2. Create a `.env` file:
   ```env
   OPENAI_API_KEY=your_openai_api_key_here
   ```

3. Start the server:
   ```bash
   node server.js
   ```

## API Endpoint

### POST `/generate-image`
**Body:**
```json
{
  "prompt": "A lion meets a mouse in a jungle"
}
```

**Response:**
```json
{
  "imageUrl": "https://..."
}
```

---
Use this project on [Railway](https://railway.app) or locally.